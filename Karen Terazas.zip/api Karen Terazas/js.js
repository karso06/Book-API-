// Función para agregar un libro
function post() {
    // Obtener los valores del formulario
    let Titulo = document.getElementById("Titulo").value;
    let Paginas = document.getElementById("Paginas").value;
    let Autor = document.getElementById("Autor").value;
  
    // Verificar si todos los campos están llenos
    if (!Titulo || !Paginas || !Autor)
      return alert("Todos los campos son obligatorios");
  
    // Realizar una solicitud POST a la API para agregar el libro
    fetch("api.php", {
      method: "post", // Método POST para enviar datos
      headers: { "Content-Type": "application/json" }, // Especificar el tipo de contenido
      body: JSON.stringify({
        Titulo: Titulo, // Título del libro
        Paginas: Paginas, // Número de páginas
        Autor: Autor, // Autor del libro
      }),
    })
      .then(() => {
        alert("Agregado correctamente"); // Mostrar mensaje de éxito
        loadBooks(); // Recargar la lista de libros después de agregar uno nuevo
        $("#addBookModal").modal("hide"); // Cerrar el modal de agregar libro
      })
      .catch((error) => console.error("Error:", error)); // Manejar errores
  }
  
  // Función para cargar la lista de libros
  function loadBooks() {
    // Realizar una solicitud GET para obtener todos los libros
    fetch("api.php", { method: "GET" })
      .then((response) => response.json()) // Convertir la respuesta en formato JSON
      .then((data) => {
        let tableBody = document.querySelector("#librosTable tbody"); // Obtener el cuerpo de la tabla
        tableBody.innerHTML = ""; // Limpiar la tabla antes de agregar los nuevos datos

        // Recorrer los datos de los libros y agregar filas a la tabla
        data.forEach((book) => {
          let row = document.createElement("tr"); // Crear una nueva fila para cada libro
          row.innerHTML = `
                              <td>${book.id}</td> <!-- Mostrar ID del libro -->
                              <td>${book.Titulo}</td> <!-- Mostrar título -->
                              <td>${book.Paginas}</td> <!-- Mostrar número de páginas -->
                              <td>${book.Autor}</td> <!-- Mostrar autor -->
                              <td>
                                  <!-- Botones para actualizar y eliminar el libro -->
                                  <button class="btn btn-outline-info" style="width:100px" onclick="editBook(${book.id})" data-toggle="modal" data-target="#editModal">Actualizar</button>
                                  <button class="btn btn-outline-danger" style="width:100px" onclick="deleteBook(${book.id})">Eliminar</button>
                              </td>
                          `;
          tableBody.appendChild(row); // Agregar la fila a la tabla
        });
        // Inicializar DataTable para mejorar la visualización de la tabla
        $("#librosTable").DataTable();
      })
      .catch((error) => console.error("Error:", error)); // Manejar errores
  }
  
  // Función para editar un libro
  function editBook(id) {
    // Obtener los datos del libro por su ID
    fetch("api.php")
      .then((response) => response.json()) // Convertir la respuesta en formato JSON
      .then((data) => {
        // Buscar el libro correspondiente por su ID
        data = data.find((row) => row.id == id);
  
        // Rellenar los campos del modal con la información del libro
        document.getElementById("editTitulo").value = data.Titulo;
        document.getElementById("editPaginas").value = data.Paginas;
        document.getElementById("editAutor").value = data.Autor;
        
        // Actualizar el evento del botón para que actualice el libro
        document.getElementById("idupdatebtn").onclick = () =>
          updateBook(data.id); // Llamar a la función de actualización
      })
      .catch((error) => console.error("Error:", error)); // Manejar errores
  }
  
  // Función para actualizar un libro
  function updateBook(id) {
    // Obtener los valores del formulario de edición
    let Titulo = document.getElementById("editTitulo").value;
    let Paginas = document.getElementById("editPaginas").value;
    let Autor = document.getElementById("editAutor").value;
  
    // Verificar si todos los campos están llenos
    if (!Titulo || !Paginas || !Autor)
      return alert("Todos los campos son obligatorios");
  
    // Realizar una solicitud PUT para actualizar el libro
    fetch("api.php", {
      method: "PUT", // Método PUT para actualizar datos
      headers: { "Content-Type": "application/json" }, // Especificar el tipo de contenido
      body: JSON.stringify({
        id: id, // ID del libro a actualizar
        Titulo: Titulo, // Nuevo título
        Paginas: Paginas, // Nuevas páginas
        Autor: Autor, // Nuevo autor
      }),
    })
      .then(() => {
        alert("Actualizado correctamente"); // Mostrar mensaje de éxito
        loadBooks(); // Recargar la lista de libros después de actualizar
        $("#editModal").modal("hide"); // Cerrar el modal de edición
      })
      .catch((error) => console.error("Error:", error)); // Manejar errores
  }
  
  let bookIdToDelete = null; // Variable para almacenar el ID del libro a eliminar
  
  // Función para mostrar el modal de confirmación antes de eliminar un libro
  function deleteBook(id) {
    bookIdToDelete = id; // Guardar el ID del libro a eliminar
    $("#confirmDeleteModal").modal("show"); // Mostrar el modal de confirmación
  }
  
  // Manejar la confirmación de eliminación
  document.getElementById("confirmDeleteBtn").addEventListener("click", function () {
    if (bookIdToDelete !== null) {
      // Realizar una solicitud DELETE para eliminar el libro
      fetch("api.php", {
        method: "DELETE", // Método DELETE para eliminar datos
        headers: { "Content-Type": "application/json" }, // Especificar el tipo de contenido
        body: JSON.stringify({ id: bookIdToDelete }), // Enviar el ID del libro a eliminar
      })
        .then(() => {
          alert("Eliminado correctamente"); // Mostrar mensaje de éxito
          loadBooks(); // Recargar la lista de libros después de eliminar
          $("#confirmDeleteModal").modal("hide"); // Cerrar el modal de confirmación
        })
        .catch((error) => console.error("Error:", error)); // Manejar errores
    }
  });
  
  // Función para filtrar los libros en la tabla por búsqueda
  function searchBooks() {
    var input = document.getElementById("searchInput"); // Obtener el valor del campo de búsqueda
    var filter = input.value.toLowerCase(); // Convertir el valor a minúsculas para hacer la búsqueda más flexible
    var table = document.getElementById("librosTable"); // Obtener la tabla de libros
    var tr = table.getElementsByTagName("tr"); // Obtener todas las filas de la tabla
  
    // Recorrer todas las filas de la tabla
    for (var i = 0; i < tr.length; i++) {
      var td = tr[i].getElementsByTagName("td"); // Obtener las celdas de la fila
      if (td.length > 0) {
        var title = td[1].textContent || td[1].innerText; // Obtener el texto del título
        var author = td[3].textContent || td[3].innerText; // Obtener el texto del autor
        if (
          title.toLowerCase().indexOf(filter) > -1 || // Filtrar por título
          author.toLowerCase().indexOf(filter) > -1 // Filtrar por autor
        ) {
          tr[i].style.display = ""; // Mostrar la fila si coincide con el filtro
        } else {
          tr[i].style.display = "none"; // Ocultar la fila si no coincide con el filtro
        }
      }
    }
  }
  
  // Cargar los libros al cargar la página 
  loadBooks();