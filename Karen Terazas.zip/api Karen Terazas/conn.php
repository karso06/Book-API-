<?php
$host = "localhost:3306";
$user = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=base", $user, $password);
  //  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "<br>Conectado correctamente<br>";

} catch (PDOException $e) {
    echo "Error al conectar a la base de datos: " . $e->getMessage();
}
?>
