<?php
header("Content-Type: application/json"); // Establecer el tipo de contenido como JSON
header("Access-Control-Allow-Methods: *"); // Permitir el uso de cualquier método HTTP (GET, POST, PUT, DELETE)

// Incluir el archivo de conexión a la base de datos
include "conn.php"; 

// Obtener el método HTTP de la solicitud
$method = $_SERVER["REQUEST_METHOD"]; 

// Controlador de rutas según el método HTTP
switch ($method) {
    case "GET":
        // Consulta SQL para obtener todos los libros
        $query = "SELECT * FROM libros";
        $result = $conn->query($query); // Ejecutar la consulta
        $data = $result->fetchAll(PDO::FETCH_ASSOC); // Obtener todos los resultados como un array asociativo
        echo json_encode($data); // Devolver los resultados en formato JSON
        break;

    case 'POST':
        // Leer los datos enviados en la solicitud POST
        parse_str(file_get_contents("php://input"), $_POST); // Obtener el contenido de la solicitud
        $_POST = json_decode(file_get_contents("php://input"), true); // Convertir los datos JSON a un array asociativo

        // Obtener los valores de los parámetros enviados
        $Titulo = $_POST['Titulo'];
        $Paginas = $_POST['Paginas'];
        $Autor = $_POST['Autor'];

        // Consulta SQL para insertar un nuevo libro en la base de datos
        $insert = "INSERT INTO libros (Titulo, Paginas, Autor) VALUES (:Titulo, :Paginas, :Autor)";
        $stmt = $conn->prepare($insert); // Preparar la consulta SQL
        $stmt->execute([
            ":Titulo" => $Titulo, // Asignar el título
            ":Paginas" => $Paginas, // Asignar el número de páginas
            ":Autor" => $Autor // Asignar el autor
        ]);
        header("Location: index.html"); // Redirigir al usuario a la página principal
        break;

    case 'PUT': 
        // Leer los datos enviados en la solicitud PUT
        $input = json_decode(file_get_contents("php://input"), true); // Convertir los datos JSON a un array asociativo
        
        // Verificar si los datos necesarios están presentes
        if (isset($input['id'], $input['Titulo'], $input['Paginas'], $input['Autor'])) {
            $id = $input['id'];
            $Titulo = $input['Titulo'];
            $Paginas = $input['Paginas'];
            $Autor = $input['Autor'];

            // Consulta SQL para actualizar un libro existente
            $update = "UPDATE libros SET Titulo = :Titulo, Paginas = :Paginas, Autor = :Autor WHERE id = :id";
            $stmt = $conn->prepare($update); // Preparar la consulta SQL
            $stmt->execute([
                ":Titulo" => $Titulo, // Asignar el título
                ":Paginas" => $Paginas, // Asignar el número de páginas
                ":Autor" => $Autor, // Asignar el autor
                ":id" => $id // Especificar el ID del libro a actualizar
            ]);
        }
        header("Location: index.html"); // Redirigir al usuario a la página principal
        break;

    case 'DELETE': 
        // Leer los datos enviados en la solicitud DELETE
        $input = json_decode(file_get_contents("php://input"), true); // Convertir los datos JSON a un array asociativo
        
        // Verificar si se ha proporcionado el ID del libro a eliminar
        if (isset($input['id'])) {
            $id = $input['id'];

            // Consulta SQL para eliminar un libro de la base de datos
            $delete = "DELETE FROM libros WHERE id = :id";
            $stmt = $conn->prepare($delete); // Preparar la consulta SQL
            $stmt->execute([":id" => $id]); // Ejecutar la consulta de eliminación
        }
        break;

    default:
        echo "Metodo invalido"; // Mensaje en caso de que el método HTTP no sea válido
        break;
}
?>