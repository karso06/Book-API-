-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-02-2025 a las 22:03:12
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `base`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `Titulo` varchar(100) NOT NULL,
  `Paginas` int(4) NOT NULL,
  `Autor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `Titulo`, `Paginas`, `Autor`) VALUES
(1, 'Crepúsculo ', 1008, 'Stephenie Meyer'),
(2, 'Harry Potter ', 865, 'J.K. Rowling'),
(3, 'El Señor de los Anillos', 872, 'J.R.R. Tolkien'),
(4, 'El despertar (La humanidad dominada por la inteligencia artificial)', 120, 'Miguel Mestal'),
(5, 'Leyendas de Herbozonia (El árbol de la Unión)', 292, 'Alberto Prieto Riquelme'),
(6, 'Chirimiri, la corriente de un río', 720, 'Ramiro Pinto Cañón'),
(7, 'Aquella tarde de la ultima primavera', 84, 'Javier Lombo Rodriguez'),
(8, 'Calmar la sed', 513, 'Charo Ruano'),
(9, 'Los laberintos del Caballero Oscuro (Viaje interior a Florencia)', 968, 'Eduardo Blazquez Mateos y Antonio Julio Lopez Gali'),
(10, 'Umbral de sombras. Lejos de las cosas', 144, 'Luis Melero Marcos'),
(11, 'Citas del Presidente Mao Tse-Tung', 861, 'Mao Tse-Tung'),
(12, 'El Alquimista ', 581, 'Paulo Coelho');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
